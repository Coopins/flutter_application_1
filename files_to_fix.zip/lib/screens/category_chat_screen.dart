// lib/screens/category_chat_screen.dart
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';

import '../services/transcription_service.dart';
import '../services/openai_service.dart'; // <-- your service

class CategoryChatScreen extends StatefulWidget {
  const CategoryChatScreen({
    super.key,
    this.categoryId,
    this.categoryName,
    this.languageCode, // ISO-639-1 like 'es','fr','en'…
    this.ttsLocale = 'en-US',
  });

  final String? categoryId;
  final String? categoryName;
  final String? languageCode;
  final String? ttsLocale;

  @override
  State<CategoryChatScreen> createState() => _CategoryChatScreenState();
}

class _CategoryChatScreenState extends State<CategoryChatScreen> {
  final _messages = <_Msg>[];
  final _scrollCtrl = ScrollController();
  final _recorder = AudioRecorder();
  final _tts = FlutterTts();

  bool _isProcessing = false;
  bool _isRecording = false;
  bool _ttsBusy = false;

  // Use your OpenAI client
  final _ai = OpenAIService.instance;

  @override
  void initState() {
    super.initState();
    _tts.awaitSpeakCompletion(true);
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    _tts.stop();
    super.dispose();
  }

  // ---------- Titles / labels ----------
  String get _title {
    final chip = widget.categoryName ?? 'Conversation';
    final lang = _languageLabel(widget.languageCode);
    return '$chip ($lang)';
  }

  String _languageLabel(String? code) {
    final v = (code ?? '').toLowerCase();
    switch (v) {
      case 'es':
        return 'Spanish';
      case 'ru':
        return 'Russian';
      case 'pt':
        return 'Portuguese';
      case 'ja':
        return 'Japanese';
      case 'ko':
        return 'Korean';
      case 'ro':
        return 'Romanian';
      case 'fr':
        return 'French';
      default:
        return 'English';
    }
  }

  // ---------- UX helpers ----------
  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollCtrl.hasClients) return;
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent + 120,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  // ---------- Bubbles ----------
  String _addUserBubble(String text) {
    final id = UniqueKey().toString();
    setState(() => _messages.add(_Msg(id: id, fromUser: true, text: text)));
    _scrollToEnd();
    return id;
  }

  void _updateUserBubble(String id, String newText) {
    final i = _messages.indexWhere((m) => m.id == id);
    if (i >= 0) {
      setState(() => _messages[i] = _messages[i].copyWith(text: newText));
      _scrollToEnd();
    }
  }

  void _addAssistantBubble(String text) {
    setState(() => _messages.add(_Msg(fromUser: false, text: text)));
    _scrollToEnd();
  }

  // ---------- TTS ----------
  Future<void> _speak(String text) async {
    if (text.trim().isEmpty) return;
    try {
      setState(() => _ttsBusy = true);
      await _tts.stop();
      await _tts.setLanguage(widget.ttsLocale ?? 'en-US');
      await _tts.setSpeechRate(0.40); // slowed down
      await _tts.setPitch(1.0);
      await _tts.speak(text);
    } catch (e) {
      _showSnack('TTS error: $e');
    } finally {
      setState(() => _ttsBusy = false);
      await Future.delayed(const Duration(milliseconds: 220));
    }
  }

  // ---------- Recording ----------
  Future<bool> _ensureMic() async {
    final st = await Permission.microphone.status;
    if (st.isGranted) return true;
    final req = await Permission.microphone.request();
    if (req.isGranted) return true;
    _showSnack('Microphone permission is required.');
    return false;
  }

  Future<String?> _startRecording() async {
    try {
      if (!await _ensureMic()) return null;

      final dir = await getApplicationDocumentsDirectory();
      final path =
          '${dir.path}/chat_${DateTime.now().millisecondsSinceEpoch}.wav';

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 16000,
          numChannels: 1,
        ),
        path: path,
      );
      final ok = await _recorder.isRecording();
      if (!ok) {
        _showSnack('Recorder did not start. Try again.');
        return null;
      }
      setState(() => _isRecording = true);
      return path;
    } catch (e) {
      _showSnack('Failed to start recording: $e');
      return null;
    }
  }

  Future<File?> _stopRecording() async {
    try {
      final path = await _recorder.stop();
      setState(() => _isRecording = false);
      if (path == null) return null;

      await Future.delayed(const Duration(milliseconds: 220)); // flush
      final f = File(path);
      if (!f.existsSync()) return null;
      final bytes = await f.length();
      if (bytes < 6000) {
        _showSnack('Very short recording—please try again.');
        return null;
      }
      return f;
    } catch (e) {
      _showSnack('Failed to stop recording: $e');
      return null;
    }
  }

  // ---------- OpenAI prompt ----------
  String _systemPrompt() {
    final lang = _languageLabel(widget.languageCode);
    final category = widget.categoryName ?? 'Conversation';
    final iso = (widget.languageCode ?? 'en').toLowerCase();

    return '''
You are Gabi, a friendly, concise language coach.
- Stay within the topic: "$category".
- Speak primarily in $lang; switch to brief English only to clarify if the user is lost.
- Keep replies short (2–4 sentences) and ask 1 guiding question.
- Avoid markdown headings; simple paragraphs and short lists are OK.
- If the user code-switches, answer in $lang but acknowledge what they said.
- Language code hint: "$iso".
''';
  }

  // ---------- Flow ----------
  Future<void> _onMicPressed() async {
    if (_ttsBusy || _isProcessing) return;

    if (!_isRecording) {
      await _startRecording();
      return;
    }

    // Stop, transcribe, ask Gabi
    final file = await _stopRecording();
    if (file == null) return;

    final pendingId = _addUserBubble('(transcribing…)');

    setState(() => _isProcessing = true);
    try {
      final lang = (widget.languageCode ?? '').toLowerCase();
      final languageHint =
          const {
                'es',
                'fr',
                'de',
                'it',
                'pt',
                'en',
                'ru',
                'ja',
                'ko',
                'ro',
              }.contains(lang)
              ? lang
              : null;

      final transcript = await TranscriptionService.transcribeFile(
        file: file,
        language: languageHint,
        timeout: const Duration(seconds: 65),
      );

      final cleaned = transcript.trim();
      _updateUserBubble(
        pendingId,
        cleaned.isEmpty ? '(no transcript)' : cleaned,
      );

      // Ask OpenAI using your service
      final reply = (await _ai.chat(_systemPrompt(), cleaned)).trim();
      final safeReply =
          reply.isEmpty
              ? 'Entendido. ¿Quieres continuar con este tema?'
              : reply;

      _addAssistantBubble(safeReply);
      await _speak(safeReply);
    } catch (e) {
      _updateUserBubble(pendingId, '(no transcript)');
      _showSnack('Processing error: $e');
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<void> _onStopListening() async {
    if (_isRecording) {
      await _stopRecording();
    }
    _showSnack('Listening stopped. Tap the mic to start again.');
  }

  // ---------- UI ----------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_title)),
      body: Column(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 2,
            width: _isProcessing ? MediaQuery.of(context).size.width * 0.65 : 0,
            color: Theme.of(context).colorScheme.secondary,
            margin: const EdgeInsets.only(top: 2),
          ),
          Expanded(
            child: ListView.builder(
              controller: _scrollCtrl,
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              itemCount: _messages.length,
              itemBuilder: (_, i) {
                final m = _messages[i];
                final align =
                    m.fromUser ? Alignment.centerRight : Alignment.centerLeft;
                final bg =
                    m.fromUser
                        ? Colors.deepPurple.shade400.withOpacity(0.35)
                        : Colors.white.withOpacity(0.06);
                return Align(
                  alignment: align,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    padding: const EdgeInsets.symmetric(
                      vertical: 12,
                      horizontal: 14,
                    ),
                    decoration: BoxDecoration(
                      color: bg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white10),
                    ),
                    child: Text(
                      m.text,
                      style: Theme.of(
                        context,
                      ).textTheme.bodyLarge?.copyWith(height: 1.35),
                    ),
                  ),
                );
              },
            ),
          ),
          if (_isProcessing)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Processing…',
                  style: Theme.of(
                    context,
                  ).textTheme.bodyMedium?.copyWith(color: Colors.orangeAccent),
                ),
              ),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton.filled(
                    onPressed:
                        (_isProcessing || _ttsBusy) ? null : _onMicPressed,
                    icon: const Icon(Icons.mic),
                    tooltip:
                        _isRecording ? 'Stop & transcribe' : 'Start recording',
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed:
                        (_isProcessing || _ttsBusy) ? null : _onStopListening,
                    icon: const Icon(Icons.stop),
                    tooltip: 'Stop listening',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Msg {
  final String id;
  final bool fromUser;
  final String text;

  _Msg({String? id, required this.fromUser, required this.text})
    : id = id ?? UniqueKey().toString();

  _Msg copyWith({String? id, bool? fromUser, String? text}) => _Msg(
    id: id ?? this.id,
    fromUser: fromUser ?? this.fromUser,
    text: text ?? this.text,
  );
}
