// lib/services/stt_service.dart
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

class SttService {
  final Record _rec = Record();

  /// Start recording to a temp file. Returns when recording has begun (or throws).
  Future<void> start() async {
    // Request mic permission and init
    if (!await _rec.hasPermission()) {
      final ok = await _rec.hasPermission();
      if (!ok) {
        throw Exception('Microphone permission not granted');
      }
    }

    // Pick a temp path
    final dir = await getTemporaryDirectory();
    final filePath =
        '${dir.path}/gabgo_${DateTime.now().millisecondsSinceEpoch}.m4a';

    // Start recording (AAC is widely supported)
    await _rec.start(
      path: filePath,
      encoder: AudioEncoder.aacLc,
      bitRate: 128000,
      samplingRate: 44100,
      numChannels: 1,
    );
  }

  /// Mirror your fluency screen usage: `await _stt.isRecording`
  Future<bool> get isRecording async => await _rec.isRecording();

  /// Stop and return the recorded file path (or null if nothing recorded).
  Future<String?> stop() async {
    final path = await _rec.stop();
    if (path == null) return null;
    if (!File(path).existsSync()) return null;
    return path;
  }

  Future<void> dispose() async {
    if (await _rec.isRecording()) {
      await _rec.stop();
    }
  }
}
